
8 September 1996

			Macaulay 3.0 for Windows 95/NT  Beta 1


This is a port of Macaulay 3. 0 by Dave Bayer and Mike Stillman to the 
WIN32 platform. You can run this port under both Windows 95 and Windows NT. 
It is a true WIN32 application and cannot be run under DOS/Windows 3.1. 
This being an initial beta release, bugs are to be expected. If you notice 
any bugs, let me know and I will see whether I can fix the problem. On the 
other hand, if you are using this version of Macaulay heavily and should it 
prove stable to you, please let me know as well. At this time the port seems 
to operate flawlessly. This however, as anybody who has ever written 
software can confirm, probably just means that I didn�t do enough testing.

At a later point, time permitting, I will release the source code so that 
the program can be compiled by anybody who wishes to do so.

If you are using this port I ask that you write me an email in exchange for 
my porting work: wuebben@math.cornell.edu  It would be nice to hear where in 
the people are using it.

You must not distribute the binaries without this textfile. 

Many thanks to Dave Bayer and Mike Stillman for creating Macaulay !

best wishes,


Bernd Johannes Wuebben
Department of Mathematics
Cornell Univerity
Ithaca, NY 14850
wuebben@math.cornell.edu

